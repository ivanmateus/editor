# Editor
Simple text editor using doubly linked lists.

# Compiling and running
To compile, simply type "make all" at the terminal, and then type "make run" to run the code.
